# GASIN WIRRRRR!!!!!!!
## CodeIgniter4, Tailwindcss and MySql

CodeIgniter 4

1. Download dan ekstrak file
2. Taruh folder himatik-app di C/xampp/htdocs/
3. Impor db.sql di phpmyadmin, beri nama himatik_db
4. Buka folder di vscode
5. Buka terminal ketik npm run dev
6. Buka terminal baru ketik php spark serve
7. Buka di localhost:8080/himatikadmin/ <-- Halaman Admin -->
8. Buka di localhost:8080/ <-- Halaman User -->


MVC cacad

Bingung dengan struktur COdeIgniter 4?

Buka https://codeigniter4.github.io/userguide/ 