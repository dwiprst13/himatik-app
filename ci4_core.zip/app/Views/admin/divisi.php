<body>
    <div class="md:ml-64 min-h-screen transition-all main">
        <div class="p-4 flex">
            <h1 class="text-xl">
                Divisi
            </h1>
        </div>
        <div class=" px-3 py-4 flex justify-between">
            <div>
                <button class="mr-3 text-sm bg-blue-500 hover:bg-blue-700 text-white py-1 px-2 rounded focus:outline-none focus:shadow-outline">
                    <a href="admin/tambahadmin">Tambah</a>
                </button>
            </div>
        </div>
    </div>
</body>