<body class="flex items-center relative">
    <div class="absolute top-0 right-0 ">
        <button class="bg-white p-2 text-white hover:bg-blue-400 hover:rounded-md hover:text-black">Kembali</button>
    </div>
    <div class="w-full">
        <h2 class="text-center text-[3rem]">Haha Lupa Password Ya Diks???</h2>
        <p class="text-center text-[1.2rem]">Di inget inget sendiri yak, aku males buat fitur lupa passwordnya</p>
        <p class="text-center text-[1.2rem]">Jiakhahahaha</p>
        <p class="text-center text-[1.2rem]">Pal Pale Pale Pale</p>
        <p class="text-center text-[0.9rem]"><a href="/himatikadmin/login">tombol kembali</a> di pojok kanan atas</p>
    </div>
</body>