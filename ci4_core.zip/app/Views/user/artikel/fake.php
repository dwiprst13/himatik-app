<ul>
    <li>listkesatu</li>
    <li>listkedua</li>
    <li>listketiga</li>
    <li>listkeempat</li>
    <li>listkelima</li>
    <li>listkeenam</li>
    <li>listketujuh</li>
</ul>

<table class="pl-3">
    <tr class="flex gap-2">
        <td>-</td>
        <td>listkesatu</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listkedua</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listketiga</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listkeempat</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listkelima</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listkeenam</td>
    </tr>
    <tr class="flex gap-2">
        <td>-</td>
        <td>listketujuh</td>
    </tr>
</table>