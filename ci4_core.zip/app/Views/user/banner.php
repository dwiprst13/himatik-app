<section class="bg-gray-900 text-white">
    <div class="h-[65vh] text-center flex items-center justify-between p-12">
        <div class="block w-full md:w-1/2 mx-auto">
            <h2 class="text-[1.7rem] md:text-[2rem] lg:text-[2.4rem] xl:text-[2.8rem] font-bold">HIMATIK UAA</h2>
            <h3 class="text-[1.7rem] md:text-[2rem] lg:text-[2.4rem] xl:text-[2.3rem] font-semibold">Himpunan Mahasiswa Informatika</h3>
            <h4 class="text-[1.7rem] md:text-[2rem] lg:text-[2.4rem] xl:text-[2rem] font-semibold">Kabinet <span id="text" class="bg-gradient-to-r from-blue-500 to-blue-700 inline-block text-transparent bg-clip-text font-bold">Kode Inovasi</span></h4>
        </div>
    </div>
</section>
<script>
</script>